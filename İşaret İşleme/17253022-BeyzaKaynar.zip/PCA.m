clc;
close all;
clear;

DoublePic = double(imread('picture.jpg'));
ReshapePic = reshape(DoublePic,size(DoublePic,1)*size(DoublePic,2),3);
coeff = pca(ReshapePic);
Itransformed = ReshapePic*coeff;
Ipc1 = reshape(Itransformed(:,1),size(DoublePic,1),size(DoublePic,2));
Ipc2 = reshape(Itransformed(:,2),size(DoublePic,1),size(DoublePic,2));
Ipc3 = reshape(Itransformed(:,3),size(DoublePic,1),size(DoublePic,2));
subplot(3,2,1), imshow(Ipc1,[]);
subplot(3,2,2), imshow(Ipc2,[]);
subplot(3,2,3), imshow(Ipc3,[]);
