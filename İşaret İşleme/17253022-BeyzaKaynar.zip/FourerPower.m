clc;
close all;
clear;
workspace;
format long g;
format compact;
fontSize = 15;

% Image input section
pic = 'picture.jpg'; % Define the variable named "pic" and assigned the picture.jpg
file = fileparts(which('picture.jpg')); % Set the image's full path
fileFull = fullfile(file, pic);

% Reading image
grayImage = imread(fileFull);
% We have to getting image size
% numberOfColorBands sould equal to 1
[rows, columns, colorChannel] = size(grayImage);
if colorChannel > 1 % This mean colorful
  % Just accept the green channel so we achive the grey picture
  grayImage = grayImage(:, :, 2); % Taking green chanel
end

% Presenting the image
subplot(2, 2, 1);
imshow(grayImage, []);
caption = sprintf('Original Grayscale Image, %s', pic);
title(caption, 'FontSize', fontSize, 'Interpreter', 'None');
drawnow;
subplot(2, 2, 2);
f = abs(fft2(grayImage));
shiftedf = fftshift(f);
imshow(log(shiftedf), []);
title('FFT2', 'FontSize', fontSize, 'Interpreter', 'None');
[rows, columns] = size(shiftedf);
radialProfile = zeros(1, ceil(sqrt(rows^2+columns^2)));
count = zeros(1, ceil(sqrt(rows^2+columns^2)));
midRow = rows/2 + 1;
midCol = columns/2 + 1;
for col = 1 : columns
  for row = 1 : rows
    radius = round(sqrt((row - midRow)^2 + (col - midCol)^2));
    if radius == 0
      continue;
    end
    radialProfile(radius) = radialProfile(radius) + shiftedf(row, col);
    count(radius) = count(radius) + 1;
  end
end

% Screen output
radialProfile = radialProfile ./ count;
subplot(2, 2, 3:4);
plot(radialProfile, 'b-', 'LineWidth', 1);
grid on;
xlabel('Radius', 'FontSize', 20);
ylabel('Input Signal', 'FontSize', 20);
