clc;
close all;
clear;
pic = imread('picture.jpg'); % Define the variable named "pic" and assigned the picture.jpg.
figure;
subplot(1, 2, 1);
bar([min(pic(:))]);
xlabel(['MIN picture value = ', num2str(min(pic(:)))], 'FontSize', 20);
subplot(1, 2, 2);
bar([max(pic(:))]);
xlabel(['MAX picture value = ', num2str(max(pic(:)))], 'FontSize', 20);
