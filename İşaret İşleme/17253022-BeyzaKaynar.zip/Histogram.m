clc;
close all;
clear;
workspace;

figure; % Creating a platform with "figure" function.
pic = imread('picture.jpg');  % Define the variable named "pic" and assigned the picture.jpg.
grey = rgb2gray(pic); % Calculate the differences between grey and actual pictures.
bw = imbinarize(grey, 0.4);
horizontalProfile = sum(bw, 1);
bar(horizontalProfile);
