clc;
close all;
clear;
pic = 'picture.jpg';
subplot(1, 2, 1); % Prepare visual interface with "subplot".

% Entropy value
I = imread('picture.jpg');
bar([entropy(I)])% Counting the average picture value with "entropy" function.
xlabel(['Entropy Value = ', num2str(entropy(I))], 'FontSize', 20);

% Counting average picture value.
subplot(1, 2, 2); % Prepare visual interface with "subplot".
bar([mean(pic(:))]) % Counting the average picture value with "mean" function.
xlabel(['Picture Average Value = ', num2str(mean(pic(:)))], 'FontSize', 20);
