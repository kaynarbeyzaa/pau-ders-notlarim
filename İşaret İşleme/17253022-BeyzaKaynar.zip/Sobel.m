clc;
close all;
clear;
figure;

originalPicture = imread('picture.jpg');
subplot(3,1,1);
imshow(originalPicture);
title('Original picture');

grayPicutre=rgb2gray(originalPicture);
DoublePic=double(grayPicutre);
for i=1:size(DoublePic,1)-2
    for j=1:size(DoublePic,2)-2
        Gx=((2*DoublePic(i+2,j+1)+DoublePic(i+2,j)+DoublePic(i+2,j+2))-(2*DoublePic(i,j+1)+DoublePic(i,j)+DoublePic(i,j+2)));
        Gy=((2*DoublePic(i+1,j+2)+DoublePic(i,j+2)+DoublePic(i+2,j+2))-(2*DoublePic(i+1,j)+DoublePic(i,j)+DoublePic(i+2,j)));
        grayPicutre(i,j)=sqrt(Gx.^2+Gy.^2);
    end
end

subplot(3,1,2);
imshow(grayPicutre);
title('Sobel filtered picture');
Thresh=100;
grayPicutre=max(grayPicutre,Thresh);
grayPicutre(grayPicutre==round(Thresh))=0;
grayPicutre=uint8(grayPicutre);
subplot(3,1,3);
imshow(~grayPicutre);
title('Edge detected picture');
