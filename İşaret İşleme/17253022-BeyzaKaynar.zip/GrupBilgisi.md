## İşaret İşleme Proje Ödevi 

**Proje Konusu:** Herhangi bir örüntü tanıma, görüntü işleme uygulaması, 
sınıflandırma problemi vb. için kullanılacak herhangi bir veriye ait öznitelik matrisinin çıkarılması.

Bu proje kapsamında çalışan öğrenciler;

- 17253046 - Hasan Tezcan

- 17253018 - Musab Bahadır Bayram

- 14253506 - Şeref Batın Eryılmaz

- 17253022 - Beyza Kaynar